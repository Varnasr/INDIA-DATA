Every table published on the site, as CSV, and the source tables behind them.

Counts only. No file carries a name or an EPIC number.
columns.csv says what every column holds. The workbooks on the downloads page carry the same tables, the Chief Electoral Officers' own tables, and these notes.

india/states.csv  The names left off each state's draft roll, with the reasons each Chief Electoral Officer gave
india/lok_sabha_electors.csv  Electors in every Lok Sabha election since 1984-85, with the population of voting age
india/margins_ls2024.csv  The names left off each Lok Sabha seat against its 2024 winning margin
india/final_rolls.csv  Each final roll set against the draft, with names added and deleted after it
india/women_removed.csv  Women's share of the names left off against their share of the roll
india/process_timeline.csv  Every order, letter, court order and judgment that changed how the revision was run
india/process_schedules.csv  Each state's schedule as set and as moved
india/notices.csv  Electors kept on a draft roll but sent a notice, by state
india/cities.csv  Large cities set against their suburbs and the rest of their state
india/reserved.csv  Seats reserved for Scheduled Castes and Scheduled Tribes against general seats
india/border.csv  Districts on the international border against the interior
india/women.csv  Every count by sex the site holds, state and district
india/urban.csv  Rural, mixed and urban districts inside each state
india/factors.csv  District circumstances from NFHS-5 beside the rate, inside each state
india/disputes.csv  Every court case, resolution, protest, Form 7 dispute and software change on the disputes page, with its source
india/court_listings.csv  The hearings and deadlines ahead in the court cases on the revision, each with the report that gives its date
india/rti.csv  Every application under the Right to Information Act about the revision whose reply was published or reported, with what was asked and what came back
india/ac_change.csv  Every constituency of Tamil Nadu, Kerala, West Bengal and Uttarakhand in one table
bihar/constituencies.csv  Every Bihar constituency, with names left off or deleted by phase, reason and sex, and the 2020 to 2025 results
bihar/districts.csv  Every Bihar district, with names left off or deleted, the reasons, women's share and the range for Muslim names
hyderabad/constituencies.csv  The five Old City constituencies, with names left off the draft and summoned to hearings
hyderabad/parts.csv  Every polling part of the five Old City constituencies
tamilnadu/constituencies.csv  Every Tamil Nadu constituency, with names left off by reason and the 2021 and 2026 results
tamilnadu/districts.csv  Every Tamil Nadu district
westbengal/constituencies.csv  Every West Bengal constituency, with the fall in the roll from 2024 by sex
westbengal/districts.csv  Every West Bengal district
kerala/constituencies.csv  Every Kerala constituency, with the fall in the roll from January 2025 by sex
kerala/districts.csv  Every Kerala district
karnataka/districts.csv  Every Karnataka election district, with names left off by reason
rajasthan/constituencies.csv  Every Rajasthan constituency, with the change in the roll from 2023
rajasthan/districts.csv  Every Rajasthan district
uttarpradesh/districts.csv  Every Uttar Pradesh district, with names left off by reason
uttarpradesh/seats.csv  Every Uttar Pradesh constituency, with its district's names left off spread by 2022 electors against the 2022 margin
delhi/constituencies.csv  Every Delhi constituency, with forms not collected and the 2025 margin
delhi/districts.csv  Every Delhi district
maharashtra/districts.csv  Every Maharashtra district, with names left off by reason and notices
maharashtra/top38.csv  The 38 constituencies the CEO listed with a high share of forms not collected
gujarat/constituencies.csv  Every Gujarat constituency, with names left off by reason and the 2022 margin
gujarat/districts.csv  Every Gujarat district, with the final roll
uttarakhand/constituencies.csv  Every Uttarakhand constituency, with names added and deleted after the draft by sex
uttarakhand/districts.csv  Every Uttarakhand district
assam/assam.csv  Assam's Special Revision of 2025-26, every figure with its source
andaman/tables.csv  Every Andaman and Nicobar Islands figure with its source.
andhrapradesh/tables.csv  Every Andhra Pradesh figure with its source.
arunachal/tables.csv  Every Arunachal Pradesh figure with its source.
chandigarh/tables.csv  Every Chandigarh figure with its source.
chhattisgarh/tables.csv  Every Chhattisgarh figure with its source.
dnhdd/tables.csv  Every Dadra and Nagar Haveli and Daman and Diu figure with its source.
goa/tables.csv  Every Goa figure with its source.
haryana/tables.csv  Every Haryana figure with its source.
jharkhand/tables.csv  Every Jharkhand figure with its source.
lakshadweep/tables.csv  Every Lakshadweep figure with its source.
madhyapradesh/tables.csv  Every Madhya Pradesh figure with its source.
manipur/tables.csv  Every Manipur figure with its source.
meghalaya/tables.csv  Every Meghalaya figure with its source.
mizoram/tables.csv  Every Mizoram figure with its source.
nagaland/tables.csv  Every Nagaland figure with its source.
odisha/tables.csv  Every Odisha figure with its source.
puducherry/tables.csv  Every Puducherry figure with its source.
punjab/tables.csv  Every Punjab figure with its source.
sikkim/tables.csv  Every Sikkim figure with its source.
tripura/tables.csv  Every Tripura figure with its source.
rajasthan/press_constituencies.csv  Names left off the draft in 110 Rajasthan constituencies, as the press printed them
rajasthan/press_districts.csv  Names left off the draft in 22 Rajasthan districts, as the press printed them
maharashtra/constituencies.csv  Every Maharashtra constituency, with names left off by reason and the 2024 result
assam/constituencies.csv  Every Assam constituency, with the rolls of February 2024, the draft and the final roll

Source tables, the Chief Electoral Officers' own, as transcribed and checked:

sources/bihar/final_roll_format4b.csv  The Election Commission's Format 4B return for the final roll, seat by seat and by sex, with names added and deleted after the draft.
sources/bihar/reasons_by_ac.csv  Phase 1 names left off the draft, counted by seat, reason, sex and age band. Reasons are what the officers wrote down.
sources/hyderabad/telangana_districts.csv  The draft-roll totals for all 33 districts of Telangana.
sources/hyderabad/hyderabad_district_acs.csv  The draft-roll totals for the 15 seats of Hyderabad district.
sources/tamilnadu/asd_ac.csv  The Chief Electoral Officer's list of absent, shifted, dead and duplicate electors, counted by constituency.
sources/tamilnadu/draft_roll_ac.csv  The draft roll of 19 December 2025.
sources/tamilnadu/final_roll_ac.csv  The final roll of 23 February 2026.
sources/tamilnadu/election_roll_20260406_ac.csv  The roll of 6 April 2026, on which the 2026 election was held.
sources/tamilnadu/roll_20250106_ac.csv  The final roll of 6 January 2025, the last roll before the revision published by sex.
sources/westbengal/roll_2024_ls_ac.csv  Electors at the 2024 Lok Sabha nominations, by assembly segment. About 18 months older than the roll the revision started from.
sources/westbengal/draft_roll_ac.csv  The draft roll of 16 December 2025.
sources/westbengal/electors_nomination_2026_ac.csv  Electors on the last date of nomination for the 2026 Assembly election, by constituency and sex.
sources/westbengal/electors_phase1_district.csv  Electors in the districts voting in the first phase.
sources/westbengal/adjudication_state.csv  The outcomes of adjudication for the state, as the press reported them. Every row is flagged.
sources/kerala/roll_before_ac.csv  The final roll of the summary revision, published 6 January 2025.
sources/kerala/draft_roll_ac.csv  The draft roll of 23 December 2025.
sources/kerala/final_roll_ac.csv  The final roll of 21 February 2026.
sources/kerala/election_roll_ac.csv  The roll of 23 March 2026.
sources/karnataka/asd_district.csv  The Chief Electoral Officer's table by election district and reason.
sources/karnataka/draft_roll_district.csv  The draft roll of 24 August 2026, general and service electors.
sources/karnataka/roll_20260925_district.csv  The roll of 25 September 2026, by district and sex.
sources/karnataka/roll_20261009_district.csv  The roll of 9 October 2026, by district and sex.
sources/karnataka/notices_20261009_district.csv  Notices generated, delivered and heard by 9 October 2026, by district.
sources/karnataka/forms_20260616_20261008_district.csv  Forms received from 16 June to 8 October 2026, by district.
sources/rajasthan/electors_2023_ac.csv  Electors at the 2023 election, from the Election Commission's statistical report.
sources/rajasthan/final_roll_ac.csv  The final roll of 12 March 2026.
sources/rajasthan/final_roll_district.csv  The same roll by district.
sources/rajasthan/sir_state_summary.csv  The state figures of the press note and the fact sheet.
sources/uttarpradesh/asd_district.csv  The district table of 6 January 2026, by reason.
sources/uttarpradesh/sir_state_summary.csv  The state figures with their source.
sources/delhi/ac.csv  The Chief Electoral Officer's table of 31 August 2026.
sources/delhi/roll_20250106_ac.csv  The roll of 6 January 2025, by constituency and sex.
sources/delhi/claims_objections.csv  Forms received after the draft.
sources/delhi/state.csv  The state figures with their source.
sources/maharashtra/district_draft.csv  Annexure-1 of the press note of 31 August 2026.
sources/maharashtra/district_uncollectable.csv  Annexure-2 of the same note.
sources/maharashtra/state.csv  The state figures with their source.
sources/maharashtra/ac_roll.csv  The statement enclosed with the CEO's press note of 16 September 2026.
sources/maharashtra/ac_reasons.csv  The CEO's tables of 1 September 2026.
sources/maharashtra/ac_draft_sex.csv  The same tables.
sources/maharashtra/district_reasons.csv  The same tables.
sources/maharashtra/district_notices.csv  The CEO's release of 4 September 2026.
sources/gujarat/ac.csv  The draft of 19 December 2025, by constituency and reason.
sources/gujarat/district.csv  The same table by district.
sources/gujarat/final_district.csv  The final roll by district, with additions and deletions as printed.
sources/gujarat/eci2022_ac.csv  The Election Commission's statistical report for the 2022 assembly election: winner, runner-up, margin, electors by sex and votes polled.
sources/uttarakhand/ac.csv  Pages 3 and 4 of PN 63/2026, transcribed from a scan.
sources/uttarakhand/district_printed.csv  The district totals the note prints.
sources/uttarakhand/state.csv  The state figures of PN 36/2026 and PN 63/2026.
sources/uttarakhand/ac_draft_asdd.csv  The CEO's table of the draft of 14.07.2026, read from the PDF's text: names marked ASDD and left off, anomalies and no mapping, by seat, district and state.
sources/assam/ac_rolls.csv  The Chief Electoral Officer's tables of the final roll of 8 February 2024, the draft and the final roll, every constituency by sex.
sources/assam/state.csv  Every roll figure, as quoted by the press.
sources/assam/rules.csv  Each rule of the Special Revision set against the SIR's.
sources/assam/schedule.csv  The order's schedule.
sources/assam/nrc_2019.csv  The figures of the lists published on 31 August 2019.
sources/assam/d_voters.csv  Answers in Parliament on D-voters.
sources/assam/foreigners_tribunals.csv  Answers in Parliament on the Foreigners Tribunals.
sources/assam/detention_state.csv  Answers in Parliament on detention.
sources/assam/detention_centres.csv  Capacity and inmates by centre.
